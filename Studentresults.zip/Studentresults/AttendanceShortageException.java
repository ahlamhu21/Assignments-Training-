package com.Studentresults;

public class AttendanceShortageException extends Exception {
    public AttendanceShortageException(String message) {
        super(message);
    }
}
