package com.EmployeeManagement;


import java.io.Serializable;

public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;

    int empId;
    String empName;
    String department;
    double salary;

    //constructor
    public Employee(int empId, String empName, String department, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.department = department;
        this.salary = salary;
    }

    // display details
    public String toString() {
        return "Employee ID: " + empId +
               ", Name: " + empName +
               ", Department: " + department +
               ", Salary: $" + salary;
    }
}

