package com.EmployeeManagement;


import java.io.*;

public class EmployeeManagement {

    public static void main(String[] args) {

        
        Employee[] employees = new Employee[5];

        employees[0] = new Employee(101, "Alice", "IT", 90000);
        employees[1] = new Employee(102, "Joe", "HR", 48000);
        employees[2] = new Employee(103, "Lee", "Finance", 55000);
        employees[3] = new Employee(104, "Alex", "Marketing", 65000);
        employees[4] = new Employee(105, "Ryan", "IT", 68000);

       
        try {
            FileOutputStream fos = new FileOutputStream("employees.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeObject(employees);

            oos.close();
            fos.close();

            System.out.println("Employees saved successfully!");

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        // Read employee from file
        try {
            FileInputStream fis = new FileInputStream("employees.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);

            Employee[] savedEmployees = (Employee[]) ois.readObject();

            System.out.println("\nEmployee Details:");

            for (int i = 0; i < savedEmployees.length; i++) {
                System.out.println(savedEmployees[i]);
            }

            ois.close();
            fis.close();

        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}

