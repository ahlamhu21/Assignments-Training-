package com.javabasics;

public class MethodLab {
    public static void main(String[] args) {
        System.out.println("Part 1");
        printProfile("Asha", 21, 5.6, true, 'A');
        printProfile("Ravi", 30, 5.9, false, 'B');
        System.out.println(average(1, 2, 2));
        System.out.println(fitsInByte(127));
        System.out.println(fitsInByte(128));
        System.out.println(fitsInByte(-129));

        System.out.println("Part 2");
        System.out.println(addTexts("12", "30"));
        int r = boxTwice(21);
        System.out.println(r);
        describe(10);
        Integer a1 = 127, b1 = 127, a2 = 1000, b2 = 1000;
        System.out.println("127: equals = " + sameValue(a1, b1) + " ==" + (a1 == b1));
        System.out.println("1000: equals = " + sameValue(a2, b2) + " ==" + (a2 == b2));

        System.out.println("Part 3");
        System.out.println(truncate(9.99));
        System.out.println(truncate(-9.99));
        System.out.println(widen(7));
        overflowDemo();
        System.out.println(shiftLetter('A', 2));

        System.out.println("Part 4");
        describeValue(5);
        describeValue(2.5);
        describeValue("hi");
        describeValue('A');
        describeValue(5L);

        System.out.println("Part 5");
        int x = 1;
        tryChange(x);
        System.out.println("x = " + x);
        StringBuilder sb1 = new StringBuilder("Hi");
        appendBang(sb1);
        System.out.println(sb1);
        StringBuilder sb2 = new StringBuilder("Hi");
        replaceBuilder(sb2);
        System.out.println(sb2);
        String s = "java";
        shout(s);
        System.out.println(s);

        System.out.println("Part 6");
        StringBuilder a = new StringBuilder("cat");
        StringBuilder b = a;
        b.append("s");
        System.out.println(a);
        compareRefs();
        System.out.println(safeLength(null));
        System.out.println(safeLength("hello"));

        System.out.println("Part 7");
        System.out.println(initials("ashu", "jauhari"));
        System.out.println(clean(" HeLLo "));
        System.out.println(isPalindromeWord("Level"));
        System.out.println(isPalindromeWord("Java"));
        System.out.println(maskEmail("asha@mail.com"));

        System.out.println("Part 8");
        System.out.println(buildCsv("a", "b", "c"));
        System.out.println(edit("Hello World"));
        long t1 = timeJoin(false);
        long t2 = timeJoin(true);
        System.out.println("String +=      : " + t1 + " ns");
        System.out.println("StringBuilder : " + t2 + " ns");
        System.out.println(safeAppend(new StringBuffer("Hi"), " there"));

        System.out.println("Part 9");
        System.out.println(formatReceipt("Asha", 3, 9.99));
        System.out.println(formatReceipt("Ravi", 2, 4.5));

        System.out.println("Problem 1");
        System.out.println(toFahrenheit(0));
        System.out.println(toFahrenheit(37.5));
        System.out.println(toFahrenheit(-40));

        System.out.println("Problem 2");
        System.out.println(percent(45, 60));
        System.out.println(percent(1, 3));

        System.out.println("Problem 3");
        System.out.println(describeInt(255));
        System.out.println(describeInt(8));

        System.out.println("Problem 4");
        int px = 1, py = 2;
        swap(px, py);
        System.out.println("outside: x=" + px + " y=" + py);

        System.out.println("Problem 5");
        StringBuilder nsb = new StringBuilder("Rao");
        addTitle(nsb);
        System.out.println(nsb);
        String ns = "Rao";
        addTitleToString(ns);
        System.out.println(ns);
        System.out.println(addTitleToString(ns));

        System.out.println("Problem 6");
        System.out.println(countChar("banana", 'a'));
        System.out.println(countChar("banana", 'z'));
        System.out.println(capitalize("jAVA"));

        System.out.println("Problem 7");
        System.out.println(padLeft("42", 5, '0'));
        System.out.println(padLeft("12345", 3, '0'));
        System.out.println(joinWithDash("ab", 3));
        System.out.println(joinWithDash("x", 1));

        System.out.println("Problem 8 ");
        System.out.println(roundHalfUp(2.5));
        System.out.println(roundHalfUp(2.4));
        System.out.println(roundHalfUp(7.0));

        System.out.println("Problem 9");
        System.out.println(factorialInt(5));
        System.out.println(factorialLong(5));
        System.out.println(factorialInt(13));
        System.out.println(factorialLong(13));
        System.out.println(factorialLong(20));

        System.out.println("Problem 10");
        System.out.println(summarize("Hello World"));
        System.out.println(summarize("Sky"));
    }

    // --- Part 1 ---
    public static void printProfile(String name, int age, double height, boolean student, char grade) {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Height: " + height);
        System.out.println("Student: " + student);
        System.out.println("Grade: " + grade);
    }
    public static double average(int a, int b, int c) { return (a + b + c) / 3.0; }
    public static boolean fitsInByte(int value) { return value >= -128 && value <= 127; }

    // --- Part 2 ---
    public static int addTexts(String a, String b) { return Integer.parseInt(a) + Integer.parseInt(b); }
    public static Integer boxTwice(int x) { Integer boxed = x; return Integer.valueOf(x * 2); }
    public static void describe(Integer n) {
        System.out.println("Binary: " + Integer.toBinaryString(n));
        System.out.println("Max: " + Integer.MAX_VALUE);
        System.out.println("Compare with 10.5: " + Double.compare(n, 10.5));
    }
    public static boolean sameValue(Integer a, Integer b) { return a.equals(b); }

    // --- Part 3 ---
    public static int truncate(double d) { return (int) d; }
    public static double widen(int i) { return i; }
    public static void overflowDemo() {
        int big = 130;
        byte b = (byte) big;
        System.out.println(b);
    }
    public static char shiftLetter(char c, int by) { return (char) (c + by); }

    // --- Part 4 ---
    public static void describeValue(int v) { System.out.println("int: " + v); }
    public static void describeValue(double v) { System.out.println("double: " + v); }
    public static void describeValue(String v) { System.out.println("String: " + v); }

    // --- Part 5 ---
    public static void tryChange(int n) { n = 99; }
    public static void appendBang(StringBuilder sb) { sb.append("!"); }
    public static void replaceBuilder(StringBuilder sb) { sb = new StringBuilder("New"); }
    public static void shout(String s) { s = s.toUpperCase(); }

    // --- Part 6 ---
    public static void compareRefs() {
        String s1 = "java", s2 = "java", s3 = new String("java");
        System.out.println(s1 == s2);
        System.out.println(s1 == s3);
        System.out.println(s1.equals(s3));
    }
    public static int safeLength(String s) { if (s == null) return -1; return s.length(); }

    // --- Part 7 ---
    public static String initials(String first, String last) {
        return "" + first.toUpperCase().charAt(0) + last.toUpperCase().charAt(0);
    }
    public static String clean(String raw) { return raw.trim().toLowerCase(); }
    public static boolean isPalindromeWord(String w) {
        return w.equalsIgnoreCase(new StringBuilder(w).reverse().toString());
    }
    public static String maskEmail(String email) {
        int at = email.indexOf('@');
        String name = email.substring(0, at);
        return name.substring(0, 1) + "*".repeat(name.length() - 1) + email.substring(at);
    }

    // --- Part 8 ---
    public static String buildCsv(String a, String b, String c) {
        return new StringBuilder().append(a).append(",").append(b).append(",").append(c).toString();
    }
    public static String edit(String text) {
        StringBuilder sb = new StringBuilder(text);
        sb.insert(0, "["); sb.append("]"); sb.replace(7, 12, "Java"); sb.deleteCharAt(6);
        return sb.toString();
    }
    public static long timeJoin(boolean useBuilder) {
        long start = System.nanoTime();
        if (useBuilder) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 20000; i++) sb.append("x");
            String r = sb.toString();
        } else {
            String s = "";
            for (int i = 0; i < 20000; i++) s += "x";
        }
        return System.nanoTime() - start;
    }
    public static String safeAppend(StringBuffer sb, String part) { sb.append(part); return sb.toString(); }

    // --- Part 9 ---
    public static String formatReceipt(String customer, int quantity, double unitPrice) {
        double total = quantity * unitPrice;
        int whole = (int) total;
        StringBuilder sb = new StringBuilder();
        sb.append("Customer: ").append(customer.toUpperCase()).append("\n");
        sb.append("Qty: ").append(quantity).append(" | Price: ").append(unitPrice).append("\n");
        sb.append("Total: ").append(total).append(" (whole: ").append(whole).append(")");
        return sb.toString();
    }

    // --- Problem 1 ---
    public static double toFahrenheit(double celsius) { return celsius * 9 / 5 + 32; }

    // --- Problem 2 ---
    public static int percent(int obtained, int total) { return (int) ((double) obtained / total * 100); }

    // --- Problem 3 ---
    public static String describeInt(int n) {
        return n + " -> binary " + Integer.toBinaryString(n) + ", hex "
             + Integer.toHexString(n) + ", octal " + Integer.toOctalString(n);
    }

    // --- Problem 4 ---
    public static void swap(int a, int b) {
        int temp = a; a = b; b = temp;
        System.out.println("inside: a=" + a + " b=" + b);
    }

    // --- Problem 5 ---
    public static void addTitle(StringBuilder name) { name.insert(0, "Dr. "); }
    public static String addTitleToString(String name) { return "Dr. " + name; }

    // --- Problem 6 ---
    public static int countChar(String s, char c) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) count++;
        return count;
    }
    public static String capitalize(String word) {
        if (word == null || word.length() == 0) return word;
        return word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase();
    }

    // --- Problem 7 ---
    public static String padLeft(String s, int width, char fill) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < width - s.length(); i++) sb.append(fill);
        return sb.append(s).toString();
    }
    public static String joinWithDash(String s, int times) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) { if (i > 0) sb.append("-"); sb.append(s); }
        return sb.toString();
    }

    // --- Problem 8 ---
    public static int roundHalfUp(double d) { return (int) (d + 0.5); }

    // --- Problem 9 ---
    public static int factorialInt(int n) {
        int result = 1;
        for (int i = 1; i <= n; i++) result *= i;
        return result;
    }
    public static long factorialLong(int n) {
        long result = 1;
        for (int i = 1; i <= n; i++) result *= i;
        return result;
    }

    // --- Problem 10 ---
    public static int countVowels(String s) {
        int count = 0;
        String lower = s.toLowerCase();
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') count++;
        }
        return count;
    }
    public static String summarize(String text) {
        return "Length: " + text.length() + " | Upper: " + text.toUpperCase()
             + " | Vowels: " + countVowels(text);
    }
}