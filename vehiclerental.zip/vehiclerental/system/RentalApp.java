package com.vehiclerental.system;

import java.util.Scanner;

public class RentalApp {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of vehicles: ");
        int n = sc.nextInt();
        sc.nextLine();

        // POLYMORPHISM: parent-type array holds Car and Bike objects
        Vehicle[] vehicles = new Vehicle[n];

        for (int i = 0; i < n; i++) {
            int type;
            while (true) {
                System.out.print("Enter type (1-Car, 2-Bike): ");
                type = sc.nextInt();
                sc.nextLine();
                if (type == 1 || type == 2) break;   // valid type
                System.out.println("Invalid type, try again.");
            }

            System.out.print("Enter Vehicle Number: ");
            String num = sc.next();
            System.out.print("Enter Model: ");
            String model = sc.next();
            System.out.print("Enter Rate per Day: ");
            double rate = sc.nextDouble();
            System.out.print("Enter Days: ");
            int days = sc.nextInt();

            if (type == 1) {
                System.out.print("Enter Insurance per Day: ");
                double ins = sc.nextDouble();
                vehicles[i] = new Car(num, model, rate, days, ins);   // parent ref = child object
            } else {
                vehicles[i] = new Bike(num, model, rate, days);
            }
        }

        System.out.println("--- Rental Details ---");
        double total = 0;

        // POLYMORPHISM: calls the correct overridden method at runtime
        for (Vehicle v : vehicles) {
            v.displayDetails();
            total += v.calculateRent();
        }

        System.out.println("Total Rent Collected: " + total);
        sc.close();
    }
}

	
	

