package com.vehiclerental.system;

class Car extends Vehicle {
	double insurancePerDay;
	
	
	
	Car(String vehicleNumber, String vehicleModel, double RatePerDay, int days, double insurancePerDay) {
		super(vehicleNumber, vehicleModel, RatePerDay, days);
		this.insurancePerDay = insurancePerDay;
		
	}
	
	@Override
	double calculateRent() {
	
		return super.calculateRent() + (insurancePerDay * days);
	}
		
	
	@Override
	void displayDetails() {
		System.out.println("Car | " + vehicleNumber + " | " + vehicleModel + " | " + RatePerDay + " | " + days + "| " + insurancePerDay + "| " + calculateRent());
	}
	
	

}
