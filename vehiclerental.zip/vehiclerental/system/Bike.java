package com.vehiclerental.system;

class Bike extends Vehicle {
	
	Bike(String vehicleNumber, String vehicleModel, double RatePerDay, int days) {
		super(vehicleNumber, vehicleModel, RatePerDay, days);
		
	}
	
	@Override
	double calculateRent() {
		return super.calculateRent() * 0.9; // 10% discount for bikes

	}
	
	@Override
	void displayDetails() {
		System.out.println("Bike | " + vehicleNumber + " | " + vehicleModel + " | " + RatePerDay + " | " + days + "| " + calculateRent());
	}
	
}
	