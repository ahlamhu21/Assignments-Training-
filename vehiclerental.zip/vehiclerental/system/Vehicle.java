package com.vehiclerental.system;

public class Vehicle {
	String vehicleNumber;;
	String vehicleModel;
	double RatePerDay;
	int days;
	
	Vehicle(String vehicleNumber, String vehicleModel, double RatePerDay, int days) {
		this.vehicleNumber = vehicleNumber;
		this.vehicleModel = vehicleModel;
		this.RatePerDay = RatePerDay;
		this.days = days;
	}
	
	double calculateRent() {
		return RatePerDay * days;
	}
	
	void displayDetails() {
		System.out.println("Vehiclee | " + vehicleNumber + " | " + vehicleModel + " | " + RatePerDay + " | " + days + "| " + calculateRent());
		
	}
	

}
